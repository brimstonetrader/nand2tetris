show = s

anoms :: Int -> [String]
anoms = [()]
